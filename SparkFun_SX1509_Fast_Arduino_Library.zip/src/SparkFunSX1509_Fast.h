/******************************************************************************
SparkFunSX1509_Fast.h
SparkFun SX1509 I/O Expander Library Header File
Jim Lindblom @ SparkFun Electronics
FAST edit by Brian Charles
Original Creation Date: September 21, 2015
https://github.com/sparkfun/SparkFun_SX1509_Arduino_Library

Here you'll find the Arduino code used to interface with the SX1509 I2C
16 I/O expander. There are functions to take advantage of a few things the
SX1509 provides - input/output setting, writing pins high/low, and reading 
the input value of pins

The original library handles all the features of the chip but does it in a
standard super-safe-and-easy-to-use-but-kind-of-slow way. I've modified it for
better speed and also stripped out half the features since the appllication we need
this for doesn't need any of that stuff.

Development environment specifics:
	IDE: Arduino 1.6.5
	Hardware Platform: Arduino Uno
	SX1509 Breakout Version: v2.0

This code is beerware; if you see me (or any other SparkFun employee) at the
local, and you've found our code helpful, please buy us a round!

Distributed as-is; no warranty is given.
******************************************************************************/

#include "Arduino.h"

#ifndef SparkFunSX1509_FAST_H
#define SparkFunSX1509_FAST_H

#define RECEIVE_TIMEOUT_VALUE 1000	// Timeout for I2C receive

// if set to 0 we skip even our cached pinMode checks before returning digitalRead results
// (I think it returns the output setting for output pins but I'm not 100% sure)
#define SX1509_FAST_DO_MODE_CHECKS 1
	
class SX1509_Fast
{
private:
// I2C Address of SX1509
	byte deviceAddress;
// Misc variables:
	unsigned long _clkX;
// Pin data cache:
	uint16_t pinDirCache;
	uint16_t pinDataCache;
// Config Functions:
	void configClock();
// Read Functions:
	byte readByte(byte registerAddress);
	unsigned int readWord(byte registerAddress);
	void readBytes(byte firstRegisterAddress, byte * destination, byte length);
// Write functions:
	void writeByte(byte registerAddress, byte writeValue);
	void writeWord(byte registerAddress, unsigned int writeValue);
	void writeBytes(byte firstRegisterAddress, byte * writeArray, byte length);

public:
// -----------------------------------------------------------------------------
// Constructor - SX1509_Fast: This function sets up the pins connected to the 
//		SX1509, and sets up the private deviceAddress variable.
// -----------------------------------------------------------------------------
	SX1509_Fast();

// -----------------------------------------------------------------------------
// begin(byte address, byte resetPin): This function initializes the SX1509.
//  	It begins the Wire library, resets the IC, and tries to read some 
//  	registers to prove it's connected.
// Inputs:
//		- address: should be the 7-bit address of the SX1509. This should be  
//		 one of four values - 0x3E, 0x3F, 0x70, 0x71 - all depending on what the
//		 ADDR0 and ADDR1 pins are set to
//		- i2cSpeed: This is clock speed for i2c communication. Standard speed is
//		 100000, and high speed (default here) is 400000.
// Output: Returns a 1 if communication is successful, 0 on error.
// -----------------------------------------------------------------------------
	byte begin(byte address = 0x3E, uint32_t i2cSpeed = 400000);
	
// -----------------------------------------------------------------------------
// reset(): This function software resets the SX1509. A software reset 
//  	writes a 0x12 then 0x34 to the REG_RESET as outlined in the datasheet.
// -----------------------------------------------------------------------------
	void reset();

// -----------------------------------------------------------------------------
// pinMode(byte pin, byte inOut): This function sets one of the SX1509's 16 
//		outputs to either an INPUT or OUTPUT.
//
//	Inputs:
//	 	- pin: should be a value between 0 and 15
//	 	- inOut: The Arduino INPUT and OUTPUT constants should be used for the 
//		 inOut parameter. They do what they say!
// -----------------------------------------------------------------------------
	void pinMode(byte pin, byte inOut);
	
// -----------------------------------------------------------------------------
// digitalWrite(byte pin, byte highLow): This function writes a pin to either high 
//		or low if it's configured as an OUTPUT. If the pin is configured as an 
//		INPUT, this method will activate either the PULL-UP	or PULL-DOWN
//		resistor (HIGH or LOW respectively).
//
//	Inputs:
//		- pin: The SX1509 pin number. Should be a value between 0 and 15.
//		- highLow: should be Arduino's defined HIGH or LOW constants.
// -----------------------------------------------------------------------------
	void digitalWrite(byte pin, byte highLow);

// -----------------------------------------------------------------------------
// readInputs(): This function reads the HIGH/LOW status of all pins from the SX1509
//		digitalRead() only reads from the cached data pulled down by this. You must
// 		call this before digitalRead otherwise your input states may be out of date
//
//  Output: the pin data
// -----------------------------------------------------------------------------
	uint16_t readInputs();

// -----------------------------------------------------------------------------
// digitalRead(byte pin): This function reads the HIGH/LOW status of a pin.
//		The pin should be configured as an INPUT, using the pinMode function.
//
//	Inputs:
//	 	- pin: The SX1509 pin to be read. should be a value between 0 and 15.
//  Outputs:
//		This function returns a 1 if HIGH, 0 if LOW
// -----------------------------------------------------------------------------
	byte digitalRead(byte pin);

// -----------------------------------------------------------------------------
// debounceConfig(byte configValue): This method configures the debounce time of 
//		every input.
//
//	Input:
//		- configValue: A 3-bit value configuring the debounce time.
//			000: 0.5ms
//			001: 1ms
//			010: 2ms
//			011: 4ms
//			100: 8ms
//			101: 16ms
//			110: 32ms
//			111: 64ms
// -----------------------------------------------------------------------------
	void debounceConfig(byte configVaule);
	
// -----------------------------------------------------------------------------
// debounceTime(byte configValue): This method configures the debounce time of 
//		every input to an estimated millisecond time duration.
//
//	Input:
//		- time: A millisecond duration estimating the debounce time. Actual
//		  debounce will be set to the 0.5, 1, 2, 4, 8, 16, 32, or 64 ms (whatever's closest)
// -----------------------------------------------------------------------------
	void debounceTime(byte time);

// -----------------------------------------------------------------------------
// debouncePin(byte pin): This method enables debounce on SX1509 input pin.
//
//	Input:
//		- pin: The SX1509 pin to be debounced. Should be between 0 and 15.
// -----------------------------------------------------------------------------
	void debouncePin(byte pin);
};

#endif	// #ifdef SparkFunSX1509_FAST_H
